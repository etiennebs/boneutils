import java.net.URI

plugins {
    java
    id("fabric-loom") version "1.3.+"
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(21))
    }
}

val minecraftVersion = "1.20.2"
val yarnMappings = "22.0.32+build.15" // placeholder, Gradle will use Loom to resolve
val loaderVersion = "0.14.22"

repositories {
    mavenCentral()
    maven { url = uri("https://maven.fabricmc.net/") }
    maven { url = uri("https://maven.minecraftforge.net/") }
}

dependencies {
    minecraft("com.mojang:minecraft:$minecraftVersion")
    mappings("net.fabricmc:yarn:$yarnMappings:v2")
    modImplementation("net.fabricmc:fabric-loader:$loaderVersion")
    modImplementation("net.fabricmc.fabric-api:fabric-api:0.91.6+1.20.2")
}

// basic publishing/build settings (keep simple)
tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
    options.release.set(21)
}
