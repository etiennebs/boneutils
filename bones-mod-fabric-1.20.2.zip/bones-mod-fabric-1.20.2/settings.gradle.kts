rootProject.name = "bones-mod-fabric-1.20.2"
