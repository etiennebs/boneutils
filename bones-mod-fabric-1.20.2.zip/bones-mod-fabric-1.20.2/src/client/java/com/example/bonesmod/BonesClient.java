package com.example.bonesmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.fabricmc.fabric.api.networking.v1.ClientPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.PacketByteBuf;
import io.netty.buffer.Unpooled;

public class BonesClient implements ClientModInitializer {
    private static KeyMapping dropKey;
    private static KeyMapping takeKey;

    @Override
    public void onInitializeClient() {
        dropKey = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.bonesmod.drop", GLFW.GLFW_KEY_BACKSLASH, "key.categories.bonesmod"));
        takeKey = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.bonesmod.take", GLFW.GLFW_KEY_ENTER, "key.categories.bonesmod"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (dropKey != null && dropKey.isDown()) {
                // send packet to server to drop bones
                PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
                ClientPlayNetworking.send(new ResourceLocation("bonesmod", "drop_bones"), buf);
            }

            if (takeKey != null && takeKey.isDown()) {
                // only when inside a container screen
                if (client.screen instanceof AbstractContainerScreen) {
                    PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
                    ClientPlayNetworking.send(new ResourceLocation("bonesmod", "take_bones"), buf);
                }
            }
        });
    }
}
