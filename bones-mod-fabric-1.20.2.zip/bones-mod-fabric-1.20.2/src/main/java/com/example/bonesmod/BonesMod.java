package com.example.bonesmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.UUID;

// Common mod initializer (server-side registration)
public class BonesMod implements ModInitializer {
    public static final ResourceLocation DROP_PACKET = new ResourceLocation("bonesmod", "drop_bones");
    public static final ResourceLocation TAKE_PACKET = new ResourceLocation("bonesmod", "take_bones");

    @Override
    public void onInitialize() {
        // server: register packet receivers to perform actions authoritatively
        ServerPlayNetworking.registerGlobalReceiver(DROP_PACKET, (server, player, handler, buf, responseSender) -> {
            server.execute(() -> {
                // iterate player's inventory and drop bones
                for (int i = 0; i < player.getInventory().items.size(); i++) {
                    ItemStack stack = player.getInventory().getItem(i);
                    if (stack.getItem() == Items.BONE) {
                        // copy and clear slot then drop on ground
                        ItemStack toDrop = stack.copy();
                        player.getInventory().setItem(i, ItemStack.EMPTY);
                        player.drop(toDrop, true);
                    }
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(TAKE_PACKET, (server, player, handler, buf, responseSender) -> {
            server.execute(() -> {
                // if player has an open container, take bones from the container into player inventory
                if (player.containerMenu != null) {
                    List<Slot> slots = player.containerMenu.slots;
                    for (int i = 0; i < slots.size(); i++) {
                        Slot s = slots.get(i);
                        ItemStack stack = s.getItem();
                        if (stack.getItem() == Items.BONE) {
                            // try to insert into player's inventory
                            ItemStack copy = stack.copy();
                            boolean inserted = player.getInventory().add(copy);
                            if (inserted) {
                                s.set(ItemStack.EMPTY);
                            } else {
                                // if can't insert, leave as is
                            }
                        }
                    }
                }
            });
        });
    }
}
