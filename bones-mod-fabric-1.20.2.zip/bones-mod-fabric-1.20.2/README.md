# Bones Mod (1.20.2, Java 21, Fabric)

**Was dieses Mod macht**
- Drücke `\` (Backslash): alle Bones aus deinem Inventar werden gedroppt.
- Drücke `Enter` während du ein Container-Inventar geöffnet hast: alle Bones aus dem Container werden in dein Inventar verschoben (sofern Platz).

**Wichtig**
- Dieses Projekt nutzt Fabric (Loader + API) für Minecraft 1.20.2.
- Java 21 wird empfohlen (Projekt ist für Java 21 konfiguriert).
- Diese Implementation verwendet client→server Pakete. Für Servern gilt: Der Server muss das Mod geladen haben, sonst werden die Pakete ignoriert.

## Schnellstart (lokal)
1. Installiere Java 21 und Git.
2. Öffne ein Terminal im Projektordner.
3. Starte Codespaces / oder lokal: `./gradlew genSources` (oder `gradlew.bat genSources` auf Windows).
4. `./gradlew runClient` startet eine Entwicklungsinstanz.
5. Zum erstellten Mod: `./gradlew build` -> `build/libs/*.jar` kopieren nach `%appdata%/.minecraft/mods` oder `~/.minecraft/mods`.

## GitHub + Codespaces (kurzanleitung)
1. Erstelle ein neues GitHub-Repository (z. B. `bones-mod-fabric-1.20.2`).
2. Push diesen Projektordner (alles was in diesem ZIP ist).
3. In GitHub: klicke **Code → Codespaces → Create codespace**.
4. Codespaces kommt mit Java/Gradle; öffne ein Terminal und führe `./gradlew runClient`.
5. Um ein Build zu erstellen: `./gradlew build`. Die fertige JAR liegt in `build/libs/`.

## Dateien / Struktur
- `build.gradle.kts`, `settings.gradle.kts` — Gradle + Fabric Loom config (minimal).
- `src/main/java` — Server code / gemeinsamer Code.
- `src/client/java` — Client-only code (Keybinds + senden der Pakete).
- `src/main/resources/fabric.mod.json` — Mod-Metadaten.

## Bekannte Einschränkungen & Hinweise
- Dieses Projekt ist ein minimaler, funktionaler Prototyp. Du musst in Codespaces / lokal die Fabric-Abhängigkeiten herunterladen (Gradle erledigt das).
- Auf Multiplayer-Servern funktioniert es **nur**, wenn der Server das Mod ebenfalls installiert hat — sonst passiert nichts (Pakete werden vom Server nicht verarbeitet).
- Sicherheit: Automatisierungen wie diese können auf öffentlichen Servern als Cheating betrachtet werden. Nutze es verantwortungsvoll.
